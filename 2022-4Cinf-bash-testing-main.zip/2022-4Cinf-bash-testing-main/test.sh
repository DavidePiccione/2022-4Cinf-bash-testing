a=$1
let b=a+1
if [ $b -gt 10 ]
 then
  echo "$b"
fi