# 2022-4Cinf-bash-testing
Esercizi su Bash con TPSI
